from django.forms import ModelForm
from. models import *
from django import forms


# class RoomForm(ModelForm):
#     class Meta:
#         model = Room
#         fields = [
#             'r_number',
#             'seating_capacity'
#         ]

class LoginForm(forms.Form):
     username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={
            'placeholder': 'Username',
            'class': 'input-box'
        })
     )
     password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Password',
            'class': 'input-box'
        })
     )

class InstructorForm(ModelForm):
    class Meta:
        model = Instructor
        fields = [
            'uid',
            'name'
        ]


class MeetingTimeForm(ModelForm):
    class Meta:
        model = MeetingTime
        fields = [
            
            'time',
            'day'
        ]
        widgets = {
            
            'time': forms.Select(),
            'day': forms.Select(),
        }


class ComputerCourseForm(ModelForm):
    class Meta:
        model = ComputerCourse
        fields = ['course_number', 'course_name', 'credit_hours', 'instructors']


class ComputerSemesterForm(ModelForm):
    class Meta:
        model = ComputerSemester
        fields = ['semester', 'courses']
    
        
class ElectronicsSemesterForm(ModelForm):
    class Meta:
        model = ElectronicsSemester
        fields = ['semester', 'courses']
        

class ElectronicsCourseForm(ModelForm):
    class Meta:
        model = ElectronicsCourse
        fields = ['course_number', 'course_name', 'credit_hours', 'instructors']



class SelectsemesterForm(forms.ModelForm):
    class Meta:
        model = Selectsemester
        fields = [ 'computersemester','electronicssemester','room_number']
        widgets={
            'computersemester':forms.Select(),
            'electronicssemester':forms.Select()
            
            }
        
class FixedClassComputerForm(ModelForm):
    class Meta:
        model=FixedClassComputer
        fields=['semester','course', 'meeting_time','instructor']
        widgets={
             'semester':forms.Select(),
             'course':forms.Select(),
             'meeting_time':forms.Select(),
             'instructor':forms.Select(),
            }
        
# class FixedClassElectronicsForm(ModelForm):
#     class Meta:
#         model=FixedClassComputer
#         fields=['semester','course', 'meeting_time','instructor']
#         widgets={
#              'semester':forms.Select(),
#              'course':forms.Select(),
#              'meeting_time':forms.Select(),
#              'instructor':forms.Select(),
#             }